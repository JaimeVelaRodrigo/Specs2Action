# VCA — Entradas diarias

> Regla: toda reflexión relevante pasa por la plantilla y se registra aquí (una sección por día).

---

## YYYY-MM-DD
**Visión:** …  
**Causa:** Interno … / Externo … / Aprendizaje …  
**Acción (≤7 días):**
- [ ] Acción 1 (fecha/meta)
- [ ] Acción 2 (fecha/meta)
- [ ] Acción 3 (fecha/meta)

**Notas:** …
