## Visión (≤2 frases)
...

## Causa
- Interno:
- Externo:
- Aprendizaje:

## Acción (≤7 días)
- [ ] Acción 1 (fecha/meta)
- [ ] Acción 2 (fecha/meta)
- [ ] Acción 3 (fecha/meta)

## Registro
- Fecha:
- Enlace(s):
- Nota de cierre (1 línea):
