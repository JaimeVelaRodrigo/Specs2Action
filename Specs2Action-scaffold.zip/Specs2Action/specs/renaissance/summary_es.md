# Resumen — Spec Renaissance

*(1 página, ES)*
