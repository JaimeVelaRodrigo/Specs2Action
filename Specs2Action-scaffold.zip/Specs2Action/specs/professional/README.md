# Spec Professional

## Estado
- **Resumen (1 página)**: `summary_es.md` / `summary_en.md`
- **Versión actual**: `current/`
- **Histórico**: `versions/`

## DoD (Definición de Terminado) M1
1) Resumen ES/EN en 1 página
2) Coherencia de voz / glosario
3) Estructura limpia (yaml/json cuando aplique)
4) Índice en README raíz
5) Tag `v1.0-M1`
