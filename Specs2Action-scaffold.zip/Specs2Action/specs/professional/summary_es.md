# Resumen — Spec Professional

*(1 página, ES)*
