# Executive Summary — Spec Professional

*(1 page, EN)*
