# LinkedIn Post (Plantilla)
- Título/gancho (≤14 palabras)
- 2–3 párrafos (200–300 palabras)
- Cierre con pregunta o invitación
- Enlace opcional a README/1-pager
